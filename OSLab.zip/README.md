南京大学软件学院2020级操作系统实验

#### lab1

- 搭建 NASM+Bochs 实验平台，在该实验平台上汇编 boot.asm 并⽤Bochs虚拟机运行，显示“Hello OS world!”
- 使⽤汇编语⾔NASM实现大整数的加法和乘法

#### lab2

- 用 C/C++ 和 nasm 编写一个 FAT12 镜像查看⼯具，读取一个.img格式的文件并响应用户输入。

#### lab3

- 编写 OS 层次的 IO 程序

#### lab4

- 添加系统调用并实现读者写者问题

