import org.antlr.v4.runtime.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
public class Main
{
	public static void main(String[] args) throws IOException {
		InputStream is = System.in;
		String file = "";
		if(args.length > 0)
		{
			file = args[0];
			is = new FileInputStream(file);
		}
//		file = "\\\\wsl.localhost\\Ubuntu-20.04\\home\\yuchongyang\\Lab\\tests\\test1.sysy";
//		is = new FileInputStream(file);
		CharStream input = CharStreams.fromStream(is);
		SysYLexer lexer = new SysYLexer(input);

		ErrorLisener EL = new ErrorLisener();
		lexer.removeErrorListeners();
		lexer.addErrorListener(EL);

		for(Token temp: lexer.getAllTokens()){
			if(!EL.whether_active) {
				if(temp.getType() != 34)
					System.err.println(lexer.getRuleNames()[temp.getType()-1] + " " + temp.getText() + " at Line " + temp.getLine() + ".");
				else
				{
					String valuetext = temp.getText();
					int realvalue = 0;
					if(valuetext.startsWith("0x") || valuetext.startsWith("0X"))
					{
						realvalue = Integer.parseInt(valuetext.substring(2),16);
					}
					else if(valuetext.startsWith("0") && valuetext.length() > 1)
					{
						realvalue = Integer.parseInt(valuetext.substring(1),8);
					}
					else
						realvalue = Integer.parseInt(valuetext,10);
					String text = String.valueOf(realvalue);
					System.err.println(lexer.getRuleNames()[temp.getType()-1] + " " + text + " at Line " + temp.getLine() + ".");
				}
			}
		}
	}
}
